import{b8 as o}from"./index-DnuH6g2x.js";const t=()=>o().appContext.config.globalProperties;export{t as u};
