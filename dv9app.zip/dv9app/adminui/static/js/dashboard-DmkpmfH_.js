import{F as s,G as a}from"./index-DnuH6g2x.js";const t=()=>s.request("get",a("dashboard/app-stats"));export{t as g};
