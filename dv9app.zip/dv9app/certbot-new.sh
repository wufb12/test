#!/usr/bin/env bash
# 为 DOMAIN 指定的域名申请 Let's Encrypt 证书，并配置自动续期。
#
# 使用前确认：
#   1. DOMAIN 对应域名的 DNS A 记录指向本服务器公网 IP。
#   2. 公网 TCP 80 可访问，防火墙/安全组已放行 HTTP。
#   3. Nginx 中该域名的 80 端口 server 配置包含：
#        location ^~ /.well-known/acme-challenge/ {
#            alias /var/www/letsencrypt/.well-known/acme-challenge/;
#            default_type text/plain;
#            try_files $uri =404;
#        }
#   4. 已安装 certbot、Nginx 和 systemd。以 root 在 Linux 服务器运行。
#
# 用法：
#   chmod +x carapi-certbot.sh
#   sudo ./carapi-certbot.sh
#   可通过环境变量覆盖邮箱或 certbot 命令：
#   sudo CERTBOT_EMAIL=admin@example.com CERTBOT_BIN=/usr/local/bin/certbot ./carapi-certbot.sh
#
# 申请后将该域名 443 虚拟主机的 ssl_certificate 和 ssl_certificate_key
# 改为 /etc/letsencrypt/live/${DOMAIN}/fullchain.pem 和 privkey.pem，
# 再执行 nginx -t && systemctl reload nginx。
# 申请其他域名时只需修改下方 DOMAIN；若其 ACME location 使用其他目录，
# 同时修改 WEBROOT，并确认该域名 DNS 和 Nginx 配置正确。
# 本脚本不会改写未知位置的 Nginx 配置文件。

set -Eeuo pipefail

DOMAIN="dv9api.senpine.net"
WEBROOT="/var/www/letsencrypt"
EMAIL="${CERTBOT_EMAIL:-yishenglu@jyaaaa.com}"
CERTBOT="${CERTBOT_BIN:-$(command -v certbot || true)}"
HOOK_DIR="/etc/letsencrypt/renewal-hooks/deploy"
HOOK_FILE="${HOOK_DIR}/reload-nginx.sh"
CRON_FILE="/etc/cron.d/certbot-renewal"

fail() {
    printf '错误：%s\n' "$*" >&2
    exit 1
}

[[ "$(id -u)" -eq 0 ]] || fail "请使用 root 运行，例如 sudo $0"
[[ -n "$CERTBOT" && -x "$CERTBOT" ]] || fail "找不到可执行的 certbot，请安装 Certbot 或设置 CERTBOT_BIN"
command -v nginx >/dev/null 2>&1 || fail "找不到 nginx 命令"
command -v systemctl >/dev/null 2>&1 || fail "找不到 systemctl；此脚本按 systemd 服务器设计"
[[ -n "$EMAIL" ]] || fail "CERTBOT_EMAIL 不能为空"

mkdir -p "${WEBROOT}/.well-known/acme-challenge" "$HOOK_DIR"
chmod 755 "$WEBROOT" "${WEBROOT}/.well-known" "${WEBROOT}/.well-known/acme-challenge"

printf '检查当前 Nginx 配置...\n'
nginx -t

printf '为 %s 申请/更新证书...\n' "$DOMAIN"
"$CERTBOT" certonly \
    --webroot -w "$WEBROOT" \
    -d "$DOMAIN" \
    --email "$EMAIL" --agree-tos --no-eff-email \
    --cert-name "$DOMAIN" --non-interactive

cat > "$HOOK_FILE" <<'HOOK'
#!/usr/bin/env bash
set -Eeuo pipefail
nginx -t
systemctl reload nginx
HOOK
chmod 755 "$HOOK_FILE"

# Use the packaged Certbot timer when present. Otherwise install one daily cron job.
if systemctl list-unit-files --type=timer --no-legend 2>/dev/null | awk '{print $1}' | grep -qx 'certbot.timer'; then
    systemctl enable --now certbot.timer
    rm -f "$CRON_FILE"
    printf '已启用 certbot.timer 自动续期。\n'
else
    cat > "$CRON_FILE" <<CRON
SHELL=/bin/bash
PATH=/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin
17 3 * * * root "$CERTBOT" renew --quiet
CRON
    chmod 644 "$CRON_FILE"
    if systemctl list-unit-files --type=service --no-legend | awk '{print $1}' | grep -Eq '^(crond|cron)\.service$'; then
        if systemctl list-unit-files --type=service --no-legend | awk '{print $1}' | grep -qx 'crond.service'; then
            systemctl enable --now crond
        else
            systemctl enable --now cron
        fi
    fi
    printf '未找到 certbot.timer，已配置每日 03:17 执行续期的 cron 任务。\n'
fi

printf '\n证书申请完成。续期模拟检查...\n'
"$CERTBOT" renew --cert-name "$DOMAIN" --dry-run

printf '\n完成。请将 %s 的 443 虚拟主机证书路径改为下方路径，再运行：\n' "$DOMAIN"
printf '  nginx -t && systemctl reload nginx\n'
printf '证书路径：/etc/letsencrypt/live/%s/\n' "$DOMAIN"
