#!/bin/bash

APP_HOME="/home/car"
APP="$APP_HOME/bin/car-server"
PID_FILE="$APP_HOME/car.pid"
LOG_DIR="$APP_HOME/resource/logs"
LOG_FILE="$LOG_DIR/ginfast.log"

mkdir -p "$LOG_DIR"

if [ ! -f "$APP" ]; then
    echo "错误：程序不存在：$APP"
    exit 1
fi

chmod +x "$APP"

# 停止 PID 文件记录的旧进程
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")

    if [[ "$OLD_PID" =~ ^[0-9]+$ ]] && kill -0 "$OLD_PID" 2>/dev/null; then
        echo "正在停止旧进程：$OLD_PID"
        kill "$OLD_PID" 2>/dev/null || true

        for i in {1..15}; do
            if ! kill -0 "$OLD_PID" 2>/dev/null; then
                break
            fi
            sleep 1
        done

        if kill -0 "$OLD_PID" 2>/dev/null; then
            echo "旧进程未正常退出，强制停止：$OLD_PID"
            kill -9 "$OLD_PID" 2>/dev/null || true
            sleep 1
        fi
    fi

    rm -f "$PID_FILE"
fi

# 清理由旧启动方式留下的同名进程
OLD_PIDS=$(pgrep -f "^$APP$" || true)

if [ -n "$OLD_PIDS" ]; then
    echo "清理旧进程：$OLD_PIDS"

    for PID in $OLD_PIDS; do
        kill "$PID" 2>/dev/null || true
    done

    sleep 2

    for PID in $OLD_PIDS; do
        if kill -0 "$PID" 2>/dev/null; then
            echo "进程未退出，强制停止：$PID"
            kill -9 "$PID" 2>/dev/null || true
        fi
    done
fi

# 确保工作目录正确，以便程序读取 config/config.yml
cd "$APP_HOME" || {
    echo "错误：无法进入项目目录：$APP_HOME"
    exit 1
}

echo "正在后台启动 Car..."

# 应用内部所有日志统一写入 resource/logs/ginfast.log。
nohup "$APP" >/dev/null 2>&1 &

NEW_PID=$!
echo "$NEW_PID" > "$PID_FILE"

sleep 2

if kill -0 "$NEW_PID" 2>/dev/null; then
    echo "启动成功，PID：$NEW_PID"
    echo "日志文件：$LOG_FILE"
else
    echo "启动失败，最近日志："

    if [ -f "$LOG_FILE" ]; then
        tail -n 80 "$LOG_FILE"
    else
        echo "日志文件不存在：$LOG_FILE"
    fi

    rm -f "$PID_FILE"
    exit 1
fi