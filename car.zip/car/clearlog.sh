#!/usr/bin/env bash

set -euo pipefail

# Resolve the project directory from this script so it can be run from anywhere.
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="${SCRIPT_DIR}/resource/logs/ginfast.log"

if [[ ! -e "${LOG_FILE}" ]]; then
  echo "日志文件不存在：${LOG_FILE}" >&2
  exit 1
fi

# Truncate in place without stopping the service. The Go logger uses
# lumberjack, which reopens/writes the file in append mode, so the inode and
# permissions remain intact while its contents are removed.
command -v truncate >/dev/null 2>&1 || {
  echo "未找到 truncate 命令" >&2
  exit 1
}
truncate -s 0 -- "${LOG_FILE}"
sync

echo "已清空日志：${LOG_FILE}"
