import{F as s,G as a}from"./index-3YdFadJR.js";const t=()=>s.request("get",a("dashboard/app-stats"));export{t as g};
