import{b9 as o}from"./index-3YdFadJR.js";const t=()=>o().appContext.config.globalProperties;export{t as u};
