#!/usr/bin/env bash

set -euo pipefail

# Resolve the project directory from this script so it can be run from anywhere.
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="${SCRIPT_DIR}/resource/logs/ginfast.log"

if [[ ! -e "${LOG_FILE}" ]]; then
  echo "日志文件不存在：${LOG_FILE}" >&2
  exit 1
fi

tail -f "${LOG_FILE}"
